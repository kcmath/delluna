
2d Ising, 20**2 lattice at beta=0.4

nequi=10000, nrpt=64, nmeas=5 000

1. Compile and run potts_hist.f

2. Compile and run ana_hist.f, the output is em=-1.1172 (14).

4. Compile and run ferdi_7.f, the output is em=-1.117834.
