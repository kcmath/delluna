
Compile and run lat3d.f  (3d lattice). 

Before copy lat223.dat or lat224.dat to lat.dat.
Other lattice sizes are, of course, also possible.
