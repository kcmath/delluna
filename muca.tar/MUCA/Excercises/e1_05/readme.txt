
1. Define beta=0.2 or 0.4 in mc.par. 

2. Compile and run potts_hist.f to create the unformatted 
   data file p2d02q02.d

3. Compile and run ana_h01.f to create the formatted data
   file h2d02q2.d for beta=0.2 or h2d02q4.d for beta=0.4.

4. Use hb2.plt to to plot h2d02q2.d and hb4.plt to to plot h2d02q4.d.

5. Move the data sets created in exercise 3 into the present
   directory. Use h_e.plt to plot all data sets together to
   reproduce figure 2.
   
