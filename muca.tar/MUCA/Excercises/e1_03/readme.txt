
1. Run I2d_H0.f -> I2d_H0.d. Plot with h0.plt. 

2. I2d_rw.f reweighting to beta=0.2 (fails) -> I2d_HB.d
   Plot with h0_rw.plt.


