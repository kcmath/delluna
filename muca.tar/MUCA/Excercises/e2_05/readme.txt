
Move mu2d10q020.dat from e2_02 to the present directory

Compile and run ana_pmu.f.
Compile and run ana_b.f

gnuplot act.plt  for figure 07.
gnuplot F10q.plt for figure 09 (2d 10-state Potts part).
gnuplot S.plt    for figure 10 (2d 10-state Potts part in the orginal scale).

Further, C.plt for the specific heat.
