
 
How to create figure  fig_2dI_es (figure 1):
============================================

1. Compile and run ferdinand.f to generate ferdi.d
   Plot with ferdi.plt.

2. Get the data file mu2d02q02.d from e2_01 after 
   running p_mu.f there.

3. Run ana_pmu.f which generates p2d02q020.d.

4. gnuplot es.plt  for figure  1.
   gnuplot C.plt   for figure  5.
   gnuplot F2q.plt for figure  9 (Ising part).
   gnuplot S2q.plt for figure 10 (Ising part).
   ln partition function and "action" plots: Zln.plt and act.plt.
