 nd,nq,nla:  2  2    20    20
 Read done, hasum calculated.
 ntun,namin,namax:            84      400      800
 irec,nmucasw,mu_sweep:      787       20    64138
 acpt =                    0.245
 nequi,nrpt,nmeas:         10000       32    10000
 Jackknife analysis:
 All done.
