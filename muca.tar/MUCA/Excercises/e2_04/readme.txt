
 
1. Get the data file mu2d02q02.d from e2_01 after 
   running p_mu.f there.

2. Run ana_pmu.f which generates hb2d02q020.d and hmu2d02q020.d.

3. gnuplot hb.plt. 
