
3d 3-state Potts model, Metropolis:

beta=0.275229525=3*0.3669727/4, nequi=20 000, rpt=64, nmeas=10 000

Compile and run (in the background) potts_hist.f then ana_hist.f

actm =     0.566247195  +/-     0.002013040

Plot with h3d3q.plt
