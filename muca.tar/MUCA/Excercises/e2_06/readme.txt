
Get mu2d10q020.dat from e2_02.

Compile and run ana_pmuh.f.

gnuplot hb.plt.
