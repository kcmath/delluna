
Compile and run ferdinand. Gnuplot es_ferdi.plt.
