
1. Compile and run potts_ts.f

2. Plot with 2d10q_ts.plt.
