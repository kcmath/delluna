 RANMAR INITIALIZED.
 Initial randon number: xr =    0.116391
 lat.par: nd,nq,nla      = 2 10     20  20
          ms,mlink,nlink =       400       800       800
 mc.par:
 iuo,iud1,iseed1,iseed2,    beta
   6  11      1      0   0.000000
 Initial action:     iact  =        82
    
 MUCA Recursion:
 namin,namax,maxtun:             80       800        10
 nrec_max,nmucasw,iastep:     40000       100         1
 ntun,irec,mu_swp,acpt:     1     2163      549744    0.393
 ntun,irec,mu_swp,acpt:     2     2603      656905    0.396
 ntun,irec,mu_swp,acpt:     3     2951      774674    0.381
 ntun,irec,mu_swp,acpt:     4     3077      814788    0.378
 ntun,irec,mu_swp,acpt:     5     3158      846140    0.373
 ntun,irec,mu_swp,acpt:     6     3243      891641    0.364
 ntun,irec,mu_swp,acpt:     7     3407      960716    0.355
 ntun,irec,mu_swp,acpt:     8     3511      995679    0.353
 ntun,irec,mu_swp,acpt:     9     4148     1175239    0.353
 ntun,irec,mu_swp,acpt:    10     4269     1211480    0.352
 Muca recursions done.
   
      100000 sweeps for reaching equilibrium.
 ia_min,ia_max, acpt rate:       47      796    0.459
   
       32 times      100000 sweeps with measurements.
 irpt,ntu_m,acpt:         1         2    0.332
 irpt,ntu_m,acpt:         2         4    0.427
 irpt,ntu_m,acpt:         3         7    0.348
 irpt,ntu_m,acpt:         4         8    0.371
 irpt,ntu_m,acpt:         5        10    0.351
 irpt,ntu_m,acpt:         6        10    0.445
 irpt,ntu_m,acpt:         7        11    0.382
 irpt,ntu_m,acpt:         8        12    0.391
 irpt,ntu_m,acpt:         9        12    0.257
 irpt,ntu_m,acpt:        10        14    0.302
 irpt,ntu_m,acpt:        11        14    0.467
 irpt,ntu_m,acpt:        12        15    0.257
 irpt,ntu_m,acpt:        13        18    0.333
 irpt,ntu_m,acpt:        14        19    0.385
 irpt,ntu_m,acpt:        15        20    0.397
 irpt,ntu_m,acpt:        16        22    0.229
 irpt,ntu_m,acpt:        17        23    0.418
 irpt,ntu_m,acpt:        18        25    0.269
 irpt,ntu_m,acpt:        19        28    0.303
 irpt,ntu_m,acpt:        20        29    0.482
 irpt,ntu_m,acpt:        21        30    0.265
 irpt,ntu_m,acpt:        22        32    0.321
 irpt,ntu_m,acpt:        23        35    0.310
 irpt,ntu_m,acpt:        24        35    0.453
 irpt,ntu_m,acpt:        25        37    0.300
 irpt,ntu_m,acpt:        26        39    0.339
 irpt,ntu_m,acpt:        27        40    0.422
 irpt,ntu_m,acpt:        28        41    0.445
 irpt,ntu_m,acpt:        29        43    0.364
 irpt,ntu_m,acpt:        30        44    0.420
 irpt,ntu_m,acpt:        31        44    0.462
 irpt,ntu_m,acpt:        32        45    0.254
