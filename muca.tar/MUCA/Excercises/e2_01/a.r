 RANMAR INITIALIZED.
 Initial randon number: xr =    0.116391
 lat.par: nd,nq,nla      = 2  2     20  20
          ms,mlink,nlink =       400       800       800
 mc.par:
 iuo,iud1,iseed1,iseed2,    beta
   6  11      1      0   0.000000
 Initial action:     iact  =       396
    
 MUCA Recursion:
 namin,namax,maxtun:            400       800        10
 nrec_max,nmucasw,iastep:      8000        20         2
 ntun,irec,mu_swp,acpt:     1      388       29297    0.265
 ntun,irec,mu_swp,acpt:     2      420       31613    0.266
 ntun,irec,mu_swp,acpt:     3      445       34999    0.254
 ntun,irec,mu_swp,acpt:     4      510       40229    0.254
 ntun,irec,mu_swp,acpt:     5      518       41422    0.250
 ntun,irec,mu_swp,acpt:     6      539       42951    0.251
 ntun,irec,mu_swp,acpt:     7      628       52146    0.241
 ntun,irec,mu_swp,acpt:     8      683       56122    0.243
 ntun,irec,mu_swp,acpt:     9      715       58954    0.243
 ntun,irec,mu_swp,acpt:    10      787       64138    0.245
 Muca recursions done.
   
       10000 sweeps for reaching equilibrium.
 ia_min,ia_max, acpt rate:      348      800    0.245
   
       32 times       10000 sweeps with measurements.
 irpt,ntu_m,acpt:         1         3    0.225
 irpt,ntu_m,acpt:         2         6    0.222
 irpt,ntu_m,acpt:         3         7    0.293
 irpt,ntu_m,acpt:         4         9    0.220
 irpt,ntu_m,acpt:         5        12    0.235
 irpt,ntu_m,acpt:         6        16    0.229
 irpt,ntu_m,acpt:         7        19    0.266
 irpt,ntu_m,acpt:         8        22    0.251
 irpt,ntu_m,acpt:         9        24    0.278
 irpt,ntu_m,acpt:        10        27    0.207
 irpt,ntu_m,acpt:        11        29    0.270
 irpt,ntu_m,acpt:        12        30    0.229
 irpt,ntu_m,acpt:        13        33    0.249
 irpt,ntu_m,acpt:        14        37    0.217
 irpt,ntu_m,acpt:        15        38    0.280
 irpt,ntu_m,acpt:        16        41    0.239
 irpt,ntu_m,acpt:        17        43    0.252
 irpt,ntu_m,acpt:        18        44    0.260
 irpt,ntu_m,acpt:        19        48    0.153
 irpt,ntu_m,acpt:        20        51    0.224
 irpt,ntu_m,acpt:        21        54    0.199
 irpt,ntu_m,acpt:        22        55    0.257
 irpt,ntu_m,acpt:        23        59    0.250
 irpt,ntu_m,acpt:        24        62    0.257
 irpt,ntu_m,acpt:        25        63    0.252
 irpt,ntu_m,acpt:        26        66    0.226
 irpt,ntu_m,acpt:        27        69    0.267
 irpt,ntu_m,acpt:        28        71    0.229
 irpt,ntu_m,acpt:        29        75    0.210
 irpt,ntu_m,acpt:        30        78    0.244
 irpt,ntu_m,acpt:        31        81    0.202
 irpt,ntu_m,acpt:        32        84    0.236
