
3d Ising model, Metropolis:

beta=0.22165d0, nequi=20 000, rpt=64, nmeas=10 000

 actm =     0.673776917  +/-     0.000216691
 em   =    -1.042661503  +/-     0.001300147

 Compile and run potts_hist.f (in the background) then ana_hist.f
