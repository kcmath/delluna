 RANMAR INITIALIZED.
 Initial randon number: xr =    0.116391
 lat.par: nd,nq,nla      = 3  2     14  14  14
          ms,mlink,nlink =      2744      8232      8232
 mc.par:
 iuo,iud1,iseed1,iseed2,    beta
   6  11      1      0   0.221650
 Initial action:     iact  =      4206
