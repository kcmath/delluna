
fig_2dI_ts:
===========

1. The value of 2dI_ts_ferdi.d is obtained with
   ferdinand.f for an 80x80 lattice.

2. Run potts_ts.f   -> potts_ts.d

   Plot with 2dI_ts.plt.1

4. Run potts_ts_r.f -> potts_ts.d and compare with the previous result.

   Plot with 2dI_ts.plt.1

